import 'package:flutter_riverpod/flutter_riverpod.dart';

class PrivacyState {
  final bool cameraAllowed;
  final bool microphoneAllowed;
  final bool dndEnabled;

  const PrivacyState({
    required this.cameraAllowed,
    required this.microphoneAllowed,
    required this.dndEnabled,
  });

  PrivacyState copyWith({bool? cameraAllowed, bool? microphoneAllowed, bool? dndEnabled}) => PrivacyState(
        cameraAllowed: cameraAllowed ?? this.cameraAllowed,
        microphoneAllowed: microphoneAllowed ?? this.microphoneAllowed,
        dndEnabled: dndEnabled ?? this.dndEnabled,
      );

  factory PrivacyState.initial() => const PrivacyState(cameraAllowed: false, microphoneAllowed: false, dndEnabled: false);
}

class PrivacyNotifier extends StateNotifier<PrivacyState> {
  PrivacyNotifier() : super(PrivacyState.initial());

  void setCamera(bool v) => state = state.copyWith(cameraAllowed: v);
  void setMicrophone(bool v) => state = state.copyWith(microphoneAllowed: v);
  void setDnd(bool v) => state = state.copyWith(dndEnabled: v);
}

final privacyProvider = StateNotifierProvider<PrivacyNotifier, PrivacyState>((ref) => PrivacyNotifier());
