import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models/handoff_state.dart';

class HandoffNotifier extends StateNotifier<HandoffProgress> {
  HandoffNotifier() : super(HandoffProgress.initial());

  Future<void> start(String deviceId) async {
    state = HandoffProgress(inProgress: true, progress: 0.0, targetDeviceId: deviceId, message: 'Starting', canRollback: true);
    for (var i = 1; i <= 10; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      state = HandoffProgress(inProgress: true, progress: i / 10.0, targetDeviceId: deviceId, message: 'Stage $i/10', canRollback: true);
    }
    state = HandoffProgress(inProgress: false, progress: 1.0, targetDeviceId: deviceId, message: 'Completed', canRollback: false);
  }

  void rollback() {
    state = HandoffProgress(inProgress: false, progress: 0.0, targetDeviceId: state.targetDeviceId, message: 'Rolled back', canRollback: false);
  }
}

final handoffProvider = StateNotifierProvider<HandoffNotifier, HandoffProgress>((ref) => HandoffNotifier());
