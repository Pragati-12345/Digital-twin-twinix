import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models/copilot_intent.dart';
import '../core/services/ai_bridge_service.dart';

class CoPilotNotifier extends StateNotifier<CoPilotIntent> {
  final AIBridgeService ai;
  CoPilotNotifier(this.ai) : super(CoPilotIntent.initial());

  Future<void> parse(String utterance) async {
    final r = await ai.parseIntent(utterance);
    state = CoPilotIntent(
      text: utterance,
      intent: r['intent'] as String,
      confidence: (r['confidence'] as num).toDouble(),
      slots: (r['slots'] as Map).cast<String, dynamic>(),
    );
  }

  void reset() => state = CoPilotIntent.initial();
}

final aiBridgeProvider = Provider((ref) => AIBridgeService());
final coPilotProvider = StateNotifierProvider<CoPilotNotifier, CoPilotIntent>((ref) {
  final ai = ref.read(aiBridgeProvider);
  return CoPilotNotifier(ai);
});
