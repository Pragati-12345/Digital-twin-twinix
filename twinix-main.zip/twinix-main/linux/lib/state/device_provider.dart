import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models/device_state.dart';

class DeviceNotifier extends StateNotifier<List<DeviceInfo>> {
  DeviceNotifier() : super(const [
    DeviceInfo(id: 'phone', name: 'Galaxy Phone', available: true, batteryPercent: 72, isPrimary: true),
    DeviceInfo(id: 'tab', name: 'Galaxy Tab', available: true, batteryPercent: 58, isPrimary: false),
  ]);

  void updateDevice(DeviceInfo updated) {
    state = [
      for (final d in state) if (d.id == updated.id) updated else d,
    ];
  }

  void setPrimary(String id) {
    state = [
      for (final d in state) d.copyWith(isPrimary: d.id == id),
    ];
  }
}

final deviceProvider = StateNotifierProvider<DeviceNotifier, List<DeviceInfo>>((ref) => DeviceNotifier());
