import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models/health_metric.dart';

class HealthState {
  final SleepTwinState sleep;
  final StressTwinState stress;
  const HealthState({required this.sleep, required this.stress});

  factory HealthState.initial() => HealthState(sleep: SleepTwinState.initial(), stress: StressTwinState.initial());
}

class HealthNotifier extends StateNotifier<HealthState> {
  HealthNotifier() : super(HealthState.initial());

  void updateSleep(SleepTwinState s) => state = HealthState(sleep: s, stress: state.stress);
  void updateStress(StressTwinState s) => state = HealthState(sleep: state.sleep, stress: s);
}

final healthProvider = StateNotifierProvider<HealthNotifier, HealthState>((ref) => HealthNotifier());
