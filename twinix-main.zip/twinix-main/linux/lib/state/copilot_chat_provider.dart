import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../core/utils/constants.dart';

class ChatMessage {
  final String role; // 'user' | 'ai'
  final String text;
  const ChatMessage(this.role, this.text);
}

class CoPilotChatNotifier extends StateNotifier<List<ChatMessage>> {
  final GenerativeModel _model;
  CoPilotChatNotifier(this._model) : super(const []);

  Future<String> respondText(String prompt) async {
    state = [...state, ChatMessage('user', prompt)];
    try {
      final resp = await _model.generateContent([Content.text(prompt)]);
      final reply = resp.text ?? '⚠️ No response from AI.';
      state = [...state, ChatMessage('ai', reply)];
      return reply;
    } catch (e) {
      final err = '❌ Error: $e';
      state = [...state, ChatMessage('ai', err)];
      return err;
    }
  }
}

final geminiModelProvider = Provider<GenerativeModel>((ref) {
  return GenerativeModel(model: geminiModelName, apiKey: geminiApiKey);
});

final coPilotChatProvider =
    StateNotifierProvider<CoPilotChatNotifier, List<ChatMessage>>((ref) {
  final model = ref.read(geminiModelProvider);
  return CoPilotChatNotifier(model);
});
