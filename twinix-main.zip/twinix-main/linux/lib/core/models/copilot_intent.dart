class CoPilotIntent {
  final String text;
  final String intent;
  final double confidence;
  final Map<String, dynamic> slots;

  const CoPilotIntent({
    required this.text,
    required this.intent,
    required this.confidence,
    required this.slots,
  });

  factory CoPilotIntent.initial() => const CoPilotIntent(
        text: '',
        intent: 'none',
        confidence: 0.0,
        slots: {},
      );
}
