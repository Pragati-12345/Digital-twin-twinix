class HandoffProgress {
  final bool inProgress;
  final double progress; // 0..1
  final String? targetDeviceId;
  final String? message;
  final bool canRollback;

  const HandoffProgress({
    required this.inProgress,
    required this.progress,
    this.targetDeviceId,
    this.message,
    required this.canRollback,
  });

  factory HandoffProgress.initial() => const HandoffProgress(
        inProgress: false,
        progress: 0.0,
        targetDeviceId: null,
        message: null,
        canRollback: false,
      );
}
