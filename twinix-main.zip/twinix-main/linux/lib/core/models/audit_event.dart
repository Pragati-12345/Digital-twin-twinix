enum AuditActionType { permissionGranted, permissionDenied, purge, override, handoff, dndToggle }

class AuditEvent {
  final int? id;
  final DateTime ts;
  final AuditActionType type;
  final String message;

  AuditEvent({this.id, required this.ts, required this.type, required this.message});

  Map<String, dynamic> toMap() => {
        'id': id,
        'ts': ts.toIso8601String(),
        'type': type.name,
        'message': message,
      };

  factory AuditEvent.fromMap(Map<String, dynamic> m) => AuditEvent(
        id: m['id'] as int?,
        ts: DateTime.parse(m['ts'] as String),
        type: AuditActionType.values.firstWhere((e) => e.name == m['type']),
        message: m['message'] as String,
      );
}
