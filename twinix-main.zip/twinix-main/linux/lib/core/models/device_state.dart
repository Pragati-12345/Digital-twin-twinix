class DeviceInfo {
  final String id;
  final String name;
  final bool available;
  final int batteryPercent;
  final bool isPrimary;

  const DeviceInfo({
    required this.id,
    required this.name,
    required this.available,
    required this.batteryPercent,
    required this.isPrimary,
  });

  DeviceInfo copyWith({
    String? id,
    String? name,
    bool? available,
    int? batteryPercent,
    bool? isPrimary,
  }) => DeviceInfo(
        id: id ?? this.id,
        name: name ?? this.name,
        available: available ?? this.available,
        batteryPercent: batteryPercent ?? this.batteryPercent,
        isPrimary: isPrimary ?? this.isPrimary,
      );

  factory DeviceInfo.fromJson(Map<String, dynamic> j) => DeviceInfo(
        id: j['id'] ?? '',
        name: j['name'] ?? 'Device',
        available: j['available'] ?? false,
        batteryPercent: j['batteryPercent'] ?? 0,
        isPrimary: j['isPrimary'] ?? false,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'available': available,
        'batteryPercent': batteryPercent,
        'isPrimary': isPrimary,
      };
}
