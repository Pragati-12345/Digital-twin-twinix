import 'health_metric.dart';
import 'device_state.dart';

class TwinState {
  final SleepTwinState sleep;
  final StressTwinState stress;
  final List<DeviceInfo> devices;
  final bool dndEnabled;

  const TwinState({
    required this.sleep,
    required this.stress,
    required this.devices,
    required this.dndEnabled,
  });

  factory TwinState.initial() => TwinState(
        sleep: SleepTwinState.initial(),
        stress: StressTwinState.initial(),
        devices: const [
          DeviceInfo(id: 'phone', name: 'Galaxy Phone', available: true, batteryPercent: 72, isPrimary: true),
          DeviceInfo(id: 'tab', name: 'Galaxy Tab', available: true, batteryPercent: 58, isPrimary: false),
        ],
        dndEnabled: false,
      );
}
