class SleepTwinState {
  final double sleepDebtPct; // 0..1
  final String bedtimeRecommendation;
  final String napSuggestion;

  const SleepTwinState({
    required this.sleepDebtPct,
    required this.bedtimeRecommendation,
    required this.napSuggestion,
  });

  factory SleepTwinState.initial() => const SleepTwinState(
        sleepDebtPct: 0.2,
        bedtimeRecommendation: 'Aim for 11:00 PM',
        napSuggestion: '15 min power-nap at 4 PM',
      );
}

class StressTwinState {
  final double stressProbability; // 0..1
  final List<double> last72hTrend; // small series for plotting
  final String microBreak;

  const StressTwinState({
    required this.stressProbability,
    required this.last72hTrend,
    required this.microBreak,
  });

  factory StressTwinState.initial() => const StressTwinState(
        stressProbability: 0.28,
        last72hTrend: [0.25, 0.2, 0.18, 0.3, 0.32, 0.29, 0.28],
        microBreak: '60 sec stretch + deep breath',
      );
}
