class AuthService {
  bool _signedIn = false;

  bool get isSignedIn => _signedIn;

  Future<bool> signInAnonymously() async {
    await Future<void>.delayed(const Duration(milliseconds: 400));
    _signedIn = true;
    return _signedIn;
  }

  Future<void> signOut() async {
    _signedIn = false;
  }
}
