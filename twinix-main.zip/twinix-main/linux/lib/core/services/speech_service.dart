import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:speech_to_text/speech_to_text.dart' as stt;

typedef SpeechResult = void Function(String text, bool isFinal, double confidence);

class SpeechService {
  final stt.SpeechToText _stt = stt.SpeechToText();
  bool _available = false;
  bool _listening = false;
  String? _localeId;

  bool get isAvailable => _available;
  bool get isListening => _listening;

  Future<bool> init() async {
    if (kIsWeb) return _available = false; // camera/mic not needed on web here
    final ok = await _stt.initialize(
      onStatus: (s) {},
      onError: (e) {
        // swallow plugin errors; we handle gracefully
      },
      debugLogging: false,
    );
    _localeId = (await _stt.systemLocale())?.localeId;
    return _available = ok;
  }

  Future<void> start({required SpeechResult onResult}) async {
    if (!_available) {
      final ok = await init();
      if (!ok) return;
    }
    if (_listening) return;
    _listening = true;

    await _stt.listen(
      onResult: (res) {
        final text = res.recognizedWords;
        final conf = res.hasConfidenceRating ? res.confidence : 0.0;
        onResult(text, res.finalResult, conf);
      },
      partialResults: true,
      listenFor: const Duration(seconds: 45),
      pauseFor: const Duration(seconds: 3),
      localeId: _localeId,
      cancelOnError: true,
    );
  }

  Future<void> stop() async {
    if (!_listening) return;
    _listening = false;
    await _stt.stop();
  }

  Future<void> cancel() async {
    if (!_listening) return;
    _listening = false;
    await _stt.cancel();
  }
}
