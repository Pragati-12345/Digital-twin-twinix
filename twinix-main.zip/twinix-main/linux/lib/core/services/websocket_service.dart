import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../utils/constants.dart';

typedef WsMessageHandler = void Function(Map<String, dynamic>);

class WebSocketService {
  WebSocketChannel? _channel;

  bool get connected => _channel != null;

  void connect({required WsMessageHandler onMessage}) {
    if (_channel != null) return;
    _channel = WebSocketChannel.connect(Uri.parse(dittoWsEndpoint));
    _channel!.stream.listen((event) {
      try {
        final jsonEvent = json.decode(event as String) as Map<String, dynamic>;
        onMessage(jsonEvent);
      } catch (_) {
        // ignore malformed events
      }
    }, onDone: () => _channel = null, onError: (_) => _channel = null);

    // Send auth header (very simplified placeholder)
    _channel!.sink.add(json.encode({'type': 'auth', 'token': dittoAuthToken}));
  }

  void send(Map<String, dynamic> msg) {
    final ch = _channel;
    if (ch == null) return;
    ch.sink.add(json.encode(msg));
  }

  void dispose() {
    _channel?.sink.close();
    _channel = null;
  }
}
