import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import '../utils/constants.dart';

class DbService {
  Database? _db;

  Future<Database> get db async {
    _db ??= await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), dbName);
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
        CREATE TABLE audit_log(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ts TEXT NOT NULL,
          type TEXT NOT NULL,
          message TEXT NOT NULL
        );
        ''');
        await db.execute('''
        CREATE TABLE twin_snapshots(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ts TEXT NOT NULL,
          payload TEXT NOT NULL
        );
        ''');
        await db.execute('''
        CREATE TABLE kpis(
          key TEXT PRIMARY KEY,
          value REAL NOT NULL
        );
        ''');
        await db.execute('''
        CREATE TABLE model_outputs(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ts TEXT NOT NULL,
          kind TEXT NOT NULL,
          summary TEXT NOT NULL,
          confidence REAL NOT NULL
        );
        ''');
      },
    );
  }
}
