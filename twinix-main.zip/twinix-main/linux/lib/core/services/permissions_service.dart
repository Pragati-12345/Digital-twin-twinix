import 'package:permission_handler/permission_handler.dart';

class PermissionsService {
  Future<bool> ensureMicrophone() async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  Future<bool> ensureCamera() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  Future<Map<String, bool>> current() async {
    final cam = await Permission.camera.status;
    final mic = await Permission.microphone.status;
    return {
      'camera': cam.isGranted,
      'microphone': mic.isGranted,
    };
  }
}
