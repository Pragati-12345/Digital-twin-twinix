import 'package:sqflite/sqflite.dart' show ConflictAlgorithm;
import '../services/db_service.dart';

class KPIRepository {
  final DbService dbService;
  KPIRepository(this.dbService);

  Future<void> setLatencyMs(double v) async {
    final db = await dbService.db;
    await db.insert(
      'kpis',
      {'key': 'latency_ms', 'value': v},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<double> getLatencyMs() async {
    final db = await dbService.db;
    final res = await db.query('kpis', where: 'key=?', whereArgs: ['latency_ms'], limit: 1);
    if (res.isEmpty) return 0.0;
    return (res.first['value'] as num).toDouble();
  }
}
