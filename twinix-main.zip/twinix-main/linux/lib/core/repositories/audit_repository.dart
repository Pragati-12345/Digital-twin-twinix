import 'dart:async';
import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import '../models/audit_event.dart';
import '../services/db_service.dart';

class AuditRepository {
  final DbService dbService;
  AuditRepository(this.dbService);

  Future<int> add(AuditEvent e) async {
    final db = await dbService.db;
    return db.insert('audit_log', e.toMap());
  }

  Stream<List<AuditEvent>> feed({int limit = 100}) async* {
    final db = await dbService.db;
    yield* Stream.periodic(const Duration(seconds: 1), (_) async {
      final rows = await db.query('audit_log', orderBy: 'ts DESC', limit: limit);
      return rows.map((r) => AuditEvent.fromMap(r)).toList();
    }).asyncMap((e) async => await e);
  }

  Future<void> purge() async {
    final db = await dbService.db;
    await db.delete('audit_log');
  }
}
