import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import '../services/db_service.dart';

class TwinRepository {
  final DbService dbService;
  TwinRepository(this.dbService);

  Future<void> saveSnapshot(Map<String, dynamic> payload) async {
    final db = await dbService.db;
    await db.insert('twin_snapshots', {
      'ts': DateTime.now().toIso8601String(),
      'payload': json.encode(payload),
    });
  }
}
