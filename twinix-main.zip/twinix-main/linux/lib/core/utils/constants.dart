import 'package:flutter/material.dart';

const appName = 'Twinix';

// Stress-aware color palette (light cues)
const stressLow = Colors.green;
const stressMedium = Colors.orange;
const stressHigh = Colors.red;

// DB constants
const dbName = 'twinix.db';

// Ditto endpoints (placeholder)
const dittoWsEndpoint = 'wss://example-ditto/ws';
const dittoAuthToken = 'REPLACE_WITH_SECURE_TOKEN';

const geminiModelName = 'gemini-2.5-flash'; // or the model you want
const geminiApiKey = 'REPLACE_WITH_YOUR_API_KEY';
