import 'package:flutter/material.dart';

class PermissionChip extends StatelessWidget {
  final String label;
  final bool granted;
  final VoidCallback? onTap;
  const PermissionChip({super.key, required this.label, required this.granted, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Chip(
        label: Text(label),
        avatar: Icon(granted ? Icons.check_circle : Icons.info_outline),
        side: BorderSide(color: granted ? Colors.green : Colors.orange),
      ),
    );
  }
}
