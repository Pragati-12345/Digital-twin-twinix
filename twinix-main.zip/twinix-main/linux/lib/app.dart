import 'package:flutter/material.dart';
// import 'routing/routes.dart';
import 'features/splash/splash_screen.dart';
import 'features/auth/login_screen.dart';
import 'features/dashboard/dashboard_screen.dart';
import 'features/copilot/copilot_screen.dart';
import 'features/handoff/device_handoff_screen.dart';
import 'features/settings/settings_screen.dart';
import 'features/privacy/privacy_center_screen.dart';

class TwinixApp extends StatelessWidget {
  const TwinixApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
      visualDensity: VisualDensity.adaptivePlatformDensity,
      brightness: Brightness.light,
    );
    final darkTheme = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.dark),
      brightness: Brightness.dark,
    );
    return MaterialApp(
      title: 'Twinix',
      theme: theme,
      darkTheme: darkTheme,
      initialRoute: SplashScreen.route,
      routes: {
        SplashScreen.route: (_) => const SplashScreen(),
        LoginScreen.route: (_) => const LoginScreen(),
        DashboardScreen.route: (_) => const DashboardScreen(),
        CoPilotScreen.route: (_) => const CoPilotScreen(),
        DeviceHandoffScreen.route: (_) => const DeviceHandoffScreen(),
        SettingsScreen.route: (_) => const SettingsScreen(),
        PrivacyCenterScreen.route: (_) => const PrivacyCenterScreen(),
      },
    );
  }
}
