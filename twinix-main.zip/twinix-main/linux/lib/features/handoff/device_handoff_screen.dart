import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../state/device_provider.dart';
import '../../state/handoff_provider.dart';

class DeviceHandoffScreen extends ConsumerWidget {
  static const route = '/handoff';
  const DeviceHandoffScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final devices = ref.watch(deviceProvider);
    final progress = ref.watch(handoffProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Device Handoff')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Nearby Devices'),
            const SizedBox(height: 8),
            Expanded(
              child: ListView(
                children: devices.map((d) {
                  return Card(
                    child: ListTile(
                      title: Text(d.name),
                      subtitle: Text('${d.available ? 'Available' : 'Unavailable'} • Battery ${d.batteryPercent}%'),
                      trailing: ElevatedButton(
                        onPressed: d.available ? () => ref.read(handoffProvider.notifier).start(d.id) : null,
                        child: const Text('Handoff now'),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 8),
            if (progress.inProgress) ...[
              LinearProgressIndicator(value: progress.progress),
              const SizedBox(height: 8),
              Text(progress.message ?? 'Working…'),
              TextButton(
                onPressed: progress.canRollback ? () => ref.read(handoffProvider.notifier).rollback() : null,
                child: const Text('Cancel / Rollback'),
              ),
            ] else if (progress.progress == 1.0) ...[
              const SizedBox(height: 8),
              Text(progress.message ?? 'Completed'),
              TextButton(onPressed: () => ref.read(handoffProvider.notifier).rollback(), child: const Text('Rollback')),
            ]
          ],
        ),
      ),
    );
  }
}
