import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../../state/copilot_provider.dart';          // your existing intent parser
import '../../state/copilot_chat_provider.dart';     // new chat provider
import '../../core/services/speech_service.dart';    // new speech wrapper
import '../../core/services/permissions_service.dart';

class CoPilotScreen extends ConsumerStatefulWidget {
  static const route = '/copilot';
  const CoPilotScreen({super.key});

  @override
  ConsumerState<CoPilotScreen> createState() => _CoPilotScreenState();
}

class _CoPilotScreenState extends ConsumerState<CoPilotScreen> {
  final _tts = FlutterTts();
  final _speech = SpeechService();
  final _perms = PermissionsService();

  bool _micReady = false;
  bool _listening = false;
  String _heard = '';
  double _asrConf = 0.0;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  Future<void> _prepare() async {
    // Mic permission (Android/iOS). On Windows this is managed by OS privacy settings.
    await _perms.ensureMicrophone();
    _micReady = await _speech.init();
    if (mounted) setState(() {});
  }

  Future<void> _toggleMic() async {
    if (!_micReady) {
      _micReady = await _speech.init();
      if (!_micReady) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Microphone not available.')),
        );
        return;
      }
    }

    if (_speech.isListening) {
      await _speech.stop();
      setState(() => _listening = false);

      final text = _heard.trim();
      if (text.isEmpty) return;

      // 1) Chat response (Gemini)
      final reply = await ref.read(coPilotChatProvider.notifier).respondText(text);

      // 2) Intent parse (your on-device/AI bridge)
      await ref.read(coPilotProvider.notifier).parse(text);

      // 3) TTS speak reply
      await _tts.stop();
      await _tts.speak(reply);
      return;
    }

    // Start listening
    setState(() {
      _heard = '';
      _asrConf = 0.0;
      _listening = true;
    });

    await _speech.start(onResult: (text, isFinal, conf) {
      if (!mounted) return;
      setState(() {
        _heard = text;
        _asrConf = conf;
      });
      // Optional: auto-stop on short silence handled by pauseFor in SpeechService
      // When final result arrives we leave stop() to the user (push-to-talk UX).
    });
  }

  @override
  void dispose() {
    _tts.stop();
    _speech.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final chat = ref.watch(coPilotChatProvider);
    final intent = ref.watch(coPilotProvider); // existing intent state

    return Scaffold(
      appBar: AppBar(title: const Text('Twinix Co-Pilot')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: chat.length,
              itemBuilder: (_, i) {
                final m = chat[i];
                final isAI = m.role == 'ai';
                return Align(
                  alignment: isAI ? Alignment.centerLeft : Alignment.centerRight,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isAI
                          ? Colors.blue.withValues(alpha: 0.10)
                          : Colors.green.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(m.text),
                  ),
                );
              },
            ),
          ),
          // Intent summary (keep your explainability)
          if (intent.intent != 'none')
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Intent: ${intent.intent} • ${(intent.confidence * 100).toStringAsFixed(0)}%',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => ref.read(coPilotProvider.notifier).reset(),
                    icon: const Icon(Icons.clear),
                    label: const Text('Clear'),
                  ),
                ],
              ),
            ),
          const Divider(height: 1),
          // Push-to-talk bar
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    _listening
                        ? (_heard.isEmpty ? '🎙️ Listening…' : _heard)
                        : (_heard.isEmpty ? 'Tap mic and speak…' : _heard),
                  ),
                ),
                if (_asrConf > 0)
                  Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: Text('ASR ${(_asrConf * 100).toStringAsFixed(0)}%'),
                  ),
                ElevatedButton.icon(
                  onPressed: _toggleMic,
                  icon: Icon(_speech.isListening ? Icons.stop : Icons.mic),
                  label: Text(_speech.isListening ? 'Stop' : 'Speak'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
