import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/auth_service.dart';
import '../dashboard/dashboard_screen.dart';

class LoginScreen extends ConsumerWidget {
  static const route = '/login';
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = AuthService(); // Replace with DI if needed
    return Scaffold(
      appBar: AppBar(title: const Text('Twinix – Sign in')),
      body: Center(
        child: ElevatedButton.icon(
          icon: const Icon(Icons.login),
          label: const Text('Continue'),
          onPressed: () async {
            await auth.signInAnonymously();
            if (context.mounted) {
              Navigator.of(context).pushReplacementNamed(DashboardScreen.route);
            }
          },
        ),
      ),
    );
  }
}
