import 'package:flutter/material.dart';
import '../../../core/models/device_state.dart';

class DeviceStatusWidget extends StatelessWidget {
  final DeviceInfo info;
  const DeviceStatusWidget({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(info.isPrimary ? Icons.smartphone : Icons.devices_other_outlined),
      title: Text(info.name),
      subtitle: Text('Battery: ${info.batteryPercent}%  •  ${info.available ? 'Available' : 'Unavailable'}'),
      trailing: info.isPrimary ? const Chip(label: Text('Primary')) : const SizedBox.shrink(),
    );
  }
}
