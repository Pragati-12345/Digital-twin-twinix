import 'package:flutter/material.dart';

class HealthChartWidget extends StatelessWidget {
  final List<double> series;
  const HealthChartWidget({super.key, required this.series});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _SparklinePainter(series),
      child: Container(),
    );
  }
}

class _SparklinePainter extends CustomPainter {
  final List<double> series;
  _SparklinePainter(this.series);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;
    final path = Path();
    if (series.isEmpty) return;
    final maxV = series.reduce((a,b) => a > b ? a : b);
    final minV = series.reduce((a,b) => a < b ? a : b);
    final span = (maxV - minV).abs() < 1e-9 ? 1.0 : (maxV - minV);
    for (var i = 0; i < series.length; i++) {
      final x = size.width * (i / (series.length - 1));
      final y = size.height * (1 - ((series[i] - minV) / span));
      if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
