import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../state/health_provider.dart';
import '../../state/device_provider.dart';
import '../copilot/copilot_screen.dart';
import '../privacy/privacy_center_screen.dart';
import '../handoff/device_handoff_screen.dart';
import 'widgets/health_chart_widget.dart';
import 'widgets/device_status_widget.dart';

class DashboardScreen extends ConsumerWidget {
  static const route = '/dashboard';
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final health = ref.watch(healthProvider);
    final devices = ref.watch(deviceProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Twinix'),
        actions: [
          IconButton(
            tooltip: 'Privacy Center',
            onPressed: () => Navigator.pushNamed(context, PrivacyCenterScreen.route),
            icon: const Icon(Icons.privacy_tip_outlined),
          ),
          IconButton(
            tooltip: 'Handoff',
            onPressed: () => Navigator.pushNamed(context, DeviceHandoffScreen.route),
            icon: const Icon(Icons.output_rounded),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.pushNamed(context, CoPilotScreen.route),
        icon: const Icon(Icons.mic),
        label: const Text('Co-Pilot'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: const Text('SleepTwin'),
              subtitle: Text('Debt: ${(health.sleep.sleepDebtPct * 100).toStringAsFixed(0)}%  •  '
                  'Bedtime: ${health.sleep.bedtimeRecommendation}  •  Nap: ${health.sleep.napSuggestion}'),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('StressTwin'),
                  const SizedBox(height: 12),
                  SizedBox(height: 160, child: HealthChartWidget(series: health.stress.last72hTrend)),
                  const SizedBox(height: 8),
                  Text('Stress prob: ${(health.stress.stressProbability * 100).toStringAsFixed(0)}%'
                      ' • Micro-break: ${health.stress.microBreak}'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Devices'),
                  const SizedBox(height: 8),
                  for (final d in devices) DeviceStatusWidget(info: d),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
