import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../widgets/permission_chip.dart';
import '../../state/privacy_provider.dart';
import '../../core/services/permissions_service.dart';

class PrivacyCenterScreen extends ConsumerWidget {
  static const route = '/privacy';
  const PrivacyCenterScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final privacy = ref.watch(privacyProvider);
    final notifier = ref.read(privacyProvider.notifier);
    final perms = PermissionsService();

    return Scaffold(
      appBar: AppBar(title: const Text('Privacy Center')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Controls'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                PermissionChip(
                  label: 'Camera',
                  granted: privacy.cameraAllowed,
                  onTap: () async { final ok = await perms.ensureCamera(); notifier.setCamera(ok); },
                ),
                PermissionChip(
                  label: 'Microphone',
                  granted: privacy.microphoneAllowed,
                  onTap: () async { final ok = await perms.ensureMicrophone(); notifier.setMicrophone(ok); },
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text('Audit Feed (conceptual)'),
            const SizedBox(height: 8),
            const Expanded(
              child: Placeholder(), // Hook to AuditRepository.feed()
            ),
            const SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: () {
                // TODO: purge stored embeddings/history in DB
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Data purge requested')));
              },
              icon: const Icon(Icons.delete_forever_outlined),
              label: const Text('Purge stored embeddings & history'),
            ),
          ],
        ),
      ),
    );
  }
}
