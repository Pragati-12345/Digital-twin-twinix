class AppRoutes {
  static const splash = SplashScreenRoute();
  static const login = LoginScreenRoute();
  static const dashboard = DashboardScreenRoute();
  static const copilot = CoPilotScreenRoute();
  static const handoff = DeviceHandoffScreenRoute();
  static const settings = SettingsScreenRoute();
  static const privacy = PrivacyCenterScreenRoute();
}

class SplashScreenRoute { const SplashScreenRoute(); String get name => '/'; }
class LoginScreenRoute { const LoginScreenRoute(); String get name => '/login'; }
class DashboardScreenRoute { const DashboardScreenRoute(); String get name => '/dashboard'; }
class CoPilotScreenRoute { const CoPilotScreenRoute(); String get name => '/copilot'; }
class DeviceHandoffScreenRoute { const DeviceHandoffScreenRoute(); String get name => '/handoff'; }
class SettingsScreenRoute { const SettingsScreenRoute(); String get name => '/settings'; }
class PrivacyCenterScreenRoute { const PrivacyCenterScreenRoute(); String get name => '/privacy'; }
