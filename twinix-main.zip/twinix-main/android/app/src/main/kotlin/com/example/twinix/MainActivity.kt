package com.example.twinix

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
